let CommonUi = require("../../../DataSupply/Fs/InForUiFolder/FromBs5Json/PullData/FromJson");

let TestFunc = CommonUi.FuncReturnAsObject({inDataPk:1022});
console.log(TestFunc);