let Common = require("../../Fs/Config/Folders/PullData/getDirectories");

let result = Common.AsArrayOfObjectsWithDesign({ inDataPK: 1022 });

console.log(result);