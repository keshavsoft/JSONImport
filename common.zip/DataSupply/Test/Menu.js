let Common = require("../Fs/Reports/Menu/AsArray/WithOutFilters");

let PromiseData = Common.startfunc({ inDataPk: 1022 });

console.log("PromiseData : ", PromiseData);