// let CommonTable = require("../../../Table/ShowData");

// let ReturnDataFromJsonWithItemAndScreenNamesAsync = async ({ inJsonConfig, inItemConfig, inUserPK }) => {
//     if (inUserPK > 0) {
//         let LocalReturnData = CommonTable.OnlyShowColumns({ inJsonConfig, inItemConfig, inUserPK });
//         if (LocalReturnData.KTF) {
//             return await LocalReturnData.DataFromServer;
//         };
//     };
// };

// module.exports = {
//     ReturnDataFromJsonWithItemAndScreenNamesAsync
// };